const fs = require('fs');
const path = require('path');
const http = require('http');

// Carregar regras WCAG
const wcagRulesPath = path.join(__dirname, '../data/wcagRules.json');
const wcagRules = JSON.parse(fs.readFileSync(wcagRulesPath, 'utf8'));

// Carregar FAQs
const faqPath = path.join(__dirname, '../data/faq.json');
const faqResponses = JSON.parse(fs.readFileSync(faqPath, 'utf8'));

const getBotResponse = async (message, activeTool) => {
  // Normalizar a mensagem para facilitar a correspondência
  const normalizedMessage = message.toLowerCase().trim();
  
  // Verificar se a mensagem corresponde a alguma FAQ
  for (const [key, response] of Object.entries(faqResponses)) {
    if (normalizedMessage.includes(key)) {
      return response;
    }
  }
  
  // Verificar se a mensagem é sobre uma regra WCAG específica
  const wcagRuleMatch = wcagRules.find(rule => 
    normalizedMessage.includes(rule.id.toLowerCase()) || 
    normalizedMessage.includes(rule.name.toLowerCase())
  );
  
  if (wcagRuleMatch) {
    return `**${wcagRuleMatch.id}: ${wcagRuleMatch.name}**\n\n${wcagRuleMatch.description}\n\nCritério WCAG: ${wcagRuleMatch.wcag}`;
  }
  
  // Respostas baseadas na ferramenta ativa
  if (activeTool === 'url') {
    return 'Para analisar a acessibilidade de um site, insira a URL no campo à esquerda e clique em "Analisar".';
  }
  
  if (activeTool === 'upload') {
    return 'Para analisar a acessibilidade de um arquivo HTML, clique em "Selecionar Arquivo HTML" e escolha o arquivo que deseja analisar.';
  }
  
  if (activeTool === 'guide') {
    return 'O guia WCAG fornece diretrizes para tornar o conteúdo web mais acessível. Você pode fazer perguntas específicas sobre qualquer critério WCAG, como "O que é WCAG 2.1.1?" ou "Explique o princípio de perceptibilidade".';
  }
  
  // Se nenhuma das condições acima for atendida, usar o modelo PyTorch local
  return new Promise((resolve, reject) => {
    const data = JSON.stringify({
      message: message
    });
    
    const options = {
      hostname: 'localhost',
      port: 5001,  // Porta do serviço Python
      path: '/generate',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
      }
    };
    
    const req = http.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsedData = JSON.parse(responseData);
          resolve(parsedData.response);
        } catch (e) {
          reject(new Error('Erro ao processar resposta do modelo'));
        }
      });
    });
    
    req.on('error', (error) => {
      reject(error);
    });
    
    req.write(data);
    req.end();
  });
};

module.exports = {
  getBotResponse
};