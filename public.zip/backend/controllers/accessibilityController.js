const express = require('express');
const router = express.Router();
const accessibilityService = require('../services/accessibilityService');

router.post('/analyze-url', async (req, res) => {
  try {
    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ error: 'URL é obrigatória' });
    }
    
    const results = await accessibilityService.analyzeUrl(url);
    res.json(results);
  } catch (error) {
    console.error('Erro ao analisar URL:', error);
    res.status(500).json({ error: 'Erro ao analisar acessibilidade da URL' });
  }
});

router.post('/analyze-html', async (req, res) => {
  try {
    const { html } = req.body;
    if (!html) {
      return res.status(400).json({ error: 'Conteúdo HTML é obrigatório' });
    }
    
    const results = await accessibilityService.analyzeHtml(html);
    res.json(results);
  } catch (error) {
    console.error('Erro ao analisar HTML:', error);
    res.status(500).json({ error: 'Erro ao analisar acessibilidade do HTML' });
  }
});

module.exports = router;