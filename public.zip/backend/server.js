const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const { spawn } = require('child_process');
const accessibilityRoutes = require('./controllers/accessibilityController');
const chatbotRoutes = require('./controllers/chatbotController');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Iniciar o serviço Python para o modelo
const pythonProcess = spawn('python', ['./python/model_service.py']);

pythonProcess.stdout.on('data', (data) => {
  console.log(`Modelo PyTorch: ${data}`);
});

pythonProcess.stderr.on('data', (data) => {
  console.error(`Erro no modelo PyTorch: ${data}`);
});

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/accessibility', accessibilityRoutes);
app.use('/api/chatbot', chatbotRoutes);

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});

// Encerrar o processo Python quando o servidor for encerrado
process.on('exit', () => {
  pythonProcess.kill();
});