from flask import Flask, request, jsonify
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from sentence_transformers import SentenceTransformer
import json
import os

app = Flask(__name__)

# Carregar modelo de linguagem pequeno para rodar localmente
# Você pode escolher um modelo menor como "distilgpt2" para rodar em máquinas com menos recursos
print("Carregando modelo de linguagem...")
model_name = "distilgpt2"  # Modelo menor para rodar localmente
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

# Carregar modelo de embeddings para busca semântica
print("Carregando modelo de embeddings...")
embedding_model = SentenceTransformer('paraphrase-MiniLM-L6-v2')  # Modelo leve de embeddings

# Carregar dados de acessibilidade
script_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(os.path.dirname(script_dir), 'data')

with open(os.path.join(data_dir, 'wcagRules.json'), 'r', encoding='utf-8') as f:
    wcag_rules = json.load(f)

with open(os.path.join(data_dir, 'faq.json'), 'r', encoding='utf-8') as f:
    faq_responses = json.load(f)

# Preparar embeddings para os dados
print("Preparando embeddings para busca semântica...")
faq_texts = list(faq_responses.keys())
faq_embeddings = embedding_model.encode(faq_texts)

wcag_texts = [f"{rule['id']} {rule['name']}" for rule in wcag_rules]
wcag_embeddings = embedding_model.encode(wcag_texts)

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    message = data.get('message', '')
    
    # Busca semântica nas FAQs e regras WCAG
    query_embedding = embedding_model.encode([message])[0]
    
    # Verificar FAQs
    faq_similarities = torch.nn.functional.cosine_similarity(
        torch.tensor(query_embedding).unsqueeze(0),
        torch.tensor(faq_embeddings),
        dim=1
    )
    best_faq_idx = torch.argmax(faq_similarities).item()
    best_faq_score = faq_similarities[best_faq_idx].item()
    
    # Verificar regras WCAG
    wcag_similarities = torch.nn.functional.cosine_similarity(
        torch.tensor(query_embedding).unsqueeze(0),
        torch.tensor(wcag_embeddings),
        dim=1
    )
    best_wcag_idx = torch.argmax(wcag_similarities).item()
    best_wcag_score = wcag_similarities[best_wcag_idx].item()
    
    # Se houver uma correspondência boa nas FAQs ou regras WCAG
    if best_faq_score > 0.7:
        return jsonify({"response": faq_responses[faq_texts[best_faq_idx]]})
    elif best_wcag_score > 0.7:
        rule = wcag_rules[best_wcag_idx]
        return jsonify({
            "response": f"**{rule['id']}: {rule['name']}**\n\n{rule['description']}\n\nCritério WCAG: {rule['wcag']}"
        })
    
    # Caso contrário, gerar resposta com o modelo de linguagem
    prompt = f"Você é um assistente especializado em acessibilidade web. Responda à seguinte pergunta de forma concisa:\n\nPergunta: {message}\n\nResposta:"
    
    inputs = tokenizer(prompt, return_tensors="pt")
    outputs = model.generate(
        inputs["input_ids"],
        max_length=200,
        num_return_sequences=1,
        temperature=0.7,
        top_p=0.9,
        do_sample=True
    )
    
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    # Extrair apenas a parte da resposta após "Resposta:"
    response = response.split("Resposta:")[-1].strip()
    
    return jsonify({"response": response})

if __name__ == '__main__':
    print("Serviço do modelo iniciado em http://localhost:5001")
    app.run(host='0.0.0.0', port=5001)